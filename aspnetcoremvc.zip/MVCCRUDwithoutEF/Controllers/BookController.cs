﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using MVCCRUDwithoutEF.Data;
using MVCCRUDwithoutEF.Models;

namespace MVCCRUDwithoutEF.Controllers
{
    public class BookController : Controller
    {
        private readonly IConfiguration _configuration;

        public BookController(IConfiguration configuration)
        {
            this._configuration = configuration;
        }

        // GET: Book
        public IActionResult Index()
        {
            DataTable dtbl = new DataTable();
            string query = "select*from Books";
            using (SqlConnection sqlConnection = new SqlConnection(_configuration.GetConnectionString("DevConnection")))
            {
                SqlCommand cmd = new SqlCommand(query, sqlConnection);
                SqlDataAdapter sqlDa = new SqlDataAdapter(cmd);
                
                sqlConnection.Open();
                cmd.ExecuteNonQuery();
                sqlDa.Fill(dtbl);
                sqlConnection.Close();
            }
            return View(dtbl);
        }

        // GET: Book/AddOrEdit/
        public IActionResult AddOrEdit(int? id)
        {
           BookViewModel bookViewModel = new BookViewModel();
            if (id > 0)
                bookViewModel = FetchBookByID(id);
           return View(bookViewModel);
        }

        // POST: Book/AddOrEdit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        //public IActionResult AddOrEdit(int id, [Bind("BookID,Title,Author,Price")] BookViewModel bookViewModel)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        using (SqlConnection sqlConnection = new SqlConnection(_configuration.GetConnectionString("DevConnection")))
        //        {
        //            sqlConnection.Open();

        //            SqlCommand sqlCmd;
        //            string query;
        //            if (id == 0)
        //            {
        //                // Add operation
        //                query = "INSERT INTO Books (Title, Author, Price) VALUES (@Title, @Author, @Price)";
        //                sqlCmd = new SqlCommand(query, sqlConnection);
        //            }
        //            else
        //            {
        //                // Edit operation
        //                query = "UPDATE Books SET Title = @Title, Author = @Author, Price = @Price WHERE BookID = @BookID";
        //                sqlCmd = new SqlCommand(query, sqlConnection);
        //                sqlCmd.Parameters.AddWithValue("@BookID", id);
        //            }

        //            sqlCmd.Parameters.AddWithValue("@Title", bookViewModel.Title);
        //            sqlCmd.Parameters.AddWithValue("@Author", bookViewModel.Author);
        //            sqlCmd.Parameters.AddWithValue("@Price", bookViewModel.Price);

        //            try
        //            {
        //                sqlCmd.ExecuteNonQuery();
        //                return RedirectToAction(nameof(Index));
        //            }
        //            catch (SqlException ex)
        //            {
        //                Console.WriteLine("Error executing query: " + ex.Message);
        //                // Handle the error appropriately
        //                // You might want to return an error view or display a message to the user
        //                return View(bookViewModel);
        //            }
        //        }
        //    }
        //    return View(bookViewModel);
        //}

        public IActionResult AddOrEdit(int id, [Bind("BookID,Title,Author,Price,Pages,IsFiction,IsNonFiction,IsBiography,Country,State,City")] BookViewModel bookViewModel)
        {
            if (ModelState.IsValid)
            {
                using (SqlConnection sqlConnection = new SqlConnection(_configuration.GetConnectionString("DevConnection")))
                {
                    sqlConnection.Open();

                    SqlCommand sqlCmd;
                    string query;
                    if (id == 0)
                    {
                        // Add operation
                        query = "INSERT INTO Books (Title, Author, Price, Pages, IsFiction, IsNonFiction, IsBiography, Country, State, City) VALUES (@Title, @Author, @Price, @Pages, @IsFiction, @IsNonFiction, @IsBiography, @Country, @State, @City)";
                        sqlCmd = new SqlCommand(query, sqlConnection);
                    }
                    else
                    {
                        // Edit operation
                        query = "UPDATE Books SET Title = @Title, Author = @Author, Price = @Price, Pages = @Pages, IsFiction = @IsFiction, IsNonFiction = @IsNonFiction, IsBiography = @IsBiography, Country = @Country, State = @State, City = @City WHERE BookID = @BookID";
                        sqlCmd = new SqlCommand(query, sqlConnection);
                        sqlCmd.Parameters.AddWithValue("@BookID", id);
                    }

                    sqlCmd.Parameters.AddWithValue("@Title", bookViewModel.Title);
                    sqlCmd.Parameters.AddWithValue("@Author", bookViewModel.Author);
                    sqlCmd.Parameters.AddWithValue("@Price", bookViewModel.Price);

                    // Additional parameters for new fields
                    sqlCmd.Parameters.AddWithValue("@Pages", bookViewModel.Pages);
                    sqlCmd.Parameters.AddWithValue("@IsFiction", bookViewModel.IsFiction);
                    sqlCmd.Parameters.AddWithValue("@IsNonFiction", bookViewModel.IsNonFiction);
                    sqlCmd.Parameters.AddWithValue("@IsBiography", bookViewModel.IsBiography);
                    sqlCmd.Parameters.AddWithValue("@Country", bookViewModel.Country);
                    sqlCmd.Parameters.AddWithValue("@State", bookViewModel.State);
                    sqlCmd.Parameters.AddWithValue("@City", bookViewModel.City);

                    try
                    {
                        sqlCmd.ExecuteNonQuery();
                        return RedirectToAction(nameof(Index));
                    }
                    catch (SqlException ex)
                    {
                        Console.WriteLine("Error executing query: " + ex.Message);
                        // Handle the error appropriately
                        // You might want to return an error view or display a message to the user
                        return View(bookViewModel);
                    }
                }
            }
            return View(bookViewModel);
        }

        // GET: Book/Delete/5
        public IActionResult Delete(int? id)
        {
            BookViewModel bookViewModel = FetchBookByID(id);
            return View(bookViewModel);
        }

        // POST: Book/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            using (SqlConnection sqlConnection = new SqlConnection(_configuration.GetConnectionString("DevConnection")))
            {
                string query = $"delete from Books where BookID = {id}";
                sqlConnection.Open();
                SqlCommand sqlCmd = new SqlCommand(query, sqlConnection);
              
                sqlCmd.ExecuteNonQuery();
                sqlConnection.Close();
            }
            return RedirectToAction(nameof(Index));
        }

        [NonAction]
        //public BookViewModel FetchBookByID(int? id) 
        //{
        //    BookViewModel bookViewModel = new BookViewModel();
        //    using (SqlConnection sqlConnection = new SqlConnection(_configuration.GetConnectionString("DevConnection")))
        //    {
        //        DataTable dtbl = new DataTable();
        //        string query = $"select * from Books where BookID = {id}";
        //        sqlConnection.Open();
        //        SqlCommand cmd = new SqlCommand(query,sqlConnection);
        //        SqlDataAdapter sqlDa = new SqlDataAdapter(cmd);

        //        cmd.ExecuteNonQuery();
        //        sqlDa.Fill(dtbl);
        //        sqlConnection.Close();
        //        if(dtbl.Rows.Count == 1)
        //        {
        //            bookViewModel.BookID =Convert.ToInt32(dtbl.Rows[0]["BookID"].ToString());
        //            bookViewModel.Title = dtbl.Rows[0]["Title"].ToString();
        //            bookViewModel.Author = dtbl.Rows[0]["Author"].ToString();
        //            bookViewModel.Price = Convert.ToInt32(dtbl.Rows[0]["Price"].ToString());
        //        }
        //        return bookViewModel;
        //    }
        //}

        public BookViewModel FetchBookByID(int? id)
        {
            BookViewModel bookViewModel = new BookViewModel();
            using (SqlConnection sqlConnection = new SqlConnection(_configuration.GetConnectionString("DevConnection")))
            {
                DataTable dtbl = new DataTable();
                string query = $"SELECT * FROM Books WHERE BookID = {id}";
                sqlConnection.Open();
                SqlCommand cmd = new SqlCommand(query, sqlConnection);
                SqlDataAdapter sqlDa = new SqlDataAdapter(cmd);

                cmd.ExecuteNonQuery();
                sqlDa.Fill(dtbl);
                sqlConnection.Close();
                if (dtbl.Rows.Count == 1)
                {
                    bookViewModel.BookID = Convert.ToInt32(dtbl.Rows[0]["BookID"].ToString());
                    bookViewModel.Title = dtbl.Rows[0]["Title"].ToString();
                    bookViewModel.Author = dtbl.Rows[0]["Author"].ToString();
                    bookViewModel.Price = Convert.ToInt32(dtbl.Rows[0]["Price"].ToString());

                    // Populate additional fields
                    bookViewModel.Pages = Convert.ToInt32(dtbl.Rows[0]["Pages"].ToString());
                    bookViewModel.IsFiction = Convert.ToBoolean(dtbl.Rows[0]["IsFiction"].ToString());
                    bookViewModel.IsNonFiction = Convert.ToBoolean(dtbl.Rows[0]["IsNonFiction"].ToString());
                    bookViewModel.IsBiography = Convert.ToBoolean(dtbl.Rows[0]["IsBiography"].ToString());
                    bookViewModel.Country = dtbl.Rows[0]["Country"].ToString();
                    bookViewModel.State = dtbl.Rows[0]["State"].ToString();
                    bookViewModel.City = dtbl.Rows[0]["City"].ToString();
                }
                return bookViewModel;
            }
        }

    }
}
